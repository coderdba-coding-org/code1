ansible-playbook -u root --private-key=~/.ssh/myansible.priv -i inv/ksn2.inv deploy-full.yml
